import { useEffect, useState } from "react";
import api from "../services/api.js";

const empty = { title:"", description:"", location:"", price:"", type:"Apartment", bedrooms:1, imageUrl:"" };

export default function Dashboard({ user }) {
  const [form, setForm] = useState(empty);
  const [properties, setProperties] = useState([]);
  const [bookings, setBookings] = useState([]);

  const load = async () => {
    const [p, b] = await Promise.all([
      api.get("/properties", { params: { owner: user.id } }),
      api.get("/bookings/owner")
    ]);
    setProperties(p.data);
    setBookings(b.data);
  };

  useEffect(() => { load().catch(e => alert(e.response?.data?.message || "Could not load dashboard")); }, []);

  const submit = async e => {
    e.preventDefault();
    try {
      await api.post("/properties", { ...form, price:Number(form.price), bedrooms:Number(form.bedrooms) });
      setForm(empty);
      await load();
      alert("Property submitted. Admin approval is required before it appears publicly.");
    } catch (e) {
      alert(e.response?.data?.message || "Could not add property");
    }
  };

  const remove = async id => {
    if (!confirm("Delete this property?")) return;
    await api.delete(`/properties/${id}`);
    load();
  };

  return <div>
    <div className="mb-4">
      <h2>Welcome, {user.name}</h2>
      <p className="text-muted">Owner dashboard</p>
    </div>

    <div className="card shadow-sm p-4 mb-4">
      <h4>Add Property</h4>
      <form onSubmit={submit}>
        <div className="row g-2">
          <div className="col-md-6"><input className="form-control" placeholder="Property title" required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
          <div className="col-md-6"><input className="form-control" placeholder="Location" required value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></div>
          <div className="col-md-3"><input className="form-control" type="number" placeholder="Monthly price" required value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></div>
          <div className="col-md-3"><select className="form-select" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Apartment</option><option>House</option><option>Room</option><option>Villa</option></select></div>
          <div className="col-md-3"><input className="form-control" type="number" min="0" placeholder="Bedrooms" value={form.bedrooms} onChange={e=>setForm({...form,bedrooms:e.target.value})}/></div>
          <div className="col-md-3"><input className="form-control" placeholder="Image URL (optional)" value={form.imageUrl} onChange={e=>setForm({...form,imageUrl:e.target.value})}/></div>
          <div className="col-12"><textarea className="form-control" rows="3" placeholder="Description" required value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></div>
          <div className="col-12"><button className="btn btn-primary">Submit Property</button></div>
        </div>
      </form>
    </div>

    <h4>My Properties</h4>
    <div className="row g-3 mb-4">
      {properties.map(p => <div className="col-md-6" key={p._id}><div className="card p-3 shadow-sm">
        <h5>{p.title}</h5><p className="mb-1">{p.location} • ₹{p.price}</p>
        <span className={`badge ${p.status==="approved"?"text-bg-success":p.status==="rejected"?"text-bg-danger":"text-bg-warning"}`}>{p.status}</span>
        <button className="btn btn-outline-danger btn-sm mt-2" onClick={()=>remove(p._id)}>Delete</button>
      </div></div>)}
    </div>

    <h4>Booking Requests</h4>
    {bookings.length ? <div className="table-responsive"><table className="table table-bordered"><thead><tr><th>Property</th><th>Renter</th><th>Date</th><th>Status</th></tr></thead><tbody>
      {bookings.map(b=><tr key={b._id}><td>{b.property?.title}</td><td>{b.renter?.name}</td><td>{new Date(b.moveInDate).toLocaleDateString()}</td><td>{b.status}</td></tr>)}
    </tbody></table></div> : <p className="text-muted">No booking requests yet.</p>}
  </div>;
}
