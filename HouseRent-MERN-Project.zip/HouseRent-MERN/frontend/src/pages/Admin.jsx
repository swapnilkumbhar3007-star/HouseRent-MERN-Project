import { useEffect, useState } from "react";
import api from "../services/api.js";

export default function Admin() {
  const [properties, setProperties] = useState([]);
  const [bookings, setBookings] = useState([]);

  const load = async () => {
    const [p, b] = await Promise.all([
      api.get("/admin/properties/pending"),
      api.get("/admin/bookings")
    ]);
    setProperties(p.data);
    setBookings(b.data);
  };

  useEffect(() => { load().catch(e => alert(e.response?.data?.message || "Admin data failed")); }, []);

  const action = async (id, type) => {
    await api.put(`/admin/properties/${id}/${type}`);
    load();
  };

  return <div>
    <h2>Admin Dashboard</h2>
    <p className="text-muted">Review properties before they become public.</p>
    <div className="row g-3 mb-5">
      {properties.map(p=><div className="col-lg-6" key={p._id}><div className="card shadow-sm p-3">
        <h5>{p.title}</h5>
        <p>{p.location} • ₹{p.price} • {p.type}</p>
        <p>{p.description}</p>
        <small>Owner: {p.owner?.name} ({p.owner?.email})</small>
        <div className="d-flex gap-2 mt-3">
          <button className="btn btn-success" onClick={()=>action(p._id,"approve")}>Approve</button>
          <button className="btn btn-danger" onClick={()=>action(p._id,"reject")}>Reject</button>
        </div>
      </div></div>)}
      {!properties.length && <div className="col-12"><div className="alert alert-success">No pending properties.</div></div>}
    </div>

    <h4>All Booking Requests</h4>
    <div className="table-responsive"><table className="table table-striped table-bordered"><thead><tr><th>Property</th><th>Renter</th><th>Move-in</th><th>Status</th></tr></thead><tbody>
      {bookings.map(b=><tr key={b._id}><td>{b.property?.title}</td><td>{b.renter?.name}</td><td>{new Date(b.moveInDate).toLocaleDateString()}</td><td>{b.status}</td></tr>)}
    </tbody></table></div>
  </div>;
}
