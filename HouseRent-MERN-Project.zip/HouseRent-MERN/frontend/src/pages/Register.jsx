import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api.js";

export default function Register({ setUser }) {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();
    try {
      const { data } = await api.post("/auth/register", form);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      setUser(data.user);
      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.message || "Registration failed");
    }
  };

  return <div className="auth-card card shadow-sm p-4 mx-auto">
    <h2 className="mb-3">Create Account</h2>
    <form onSubmit={submit}>
      <input className="form-control mb-3" placeholder="Full name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
      <input className="form-control mb-3" type="email" placeholder="Email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
      <input className="form-control mb-3" type="password" minLength="6" placeholder="Password (6+ characters)" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
      <button className="btn btn-primary w-100">Register</button>
    </form>
    <p className="mt-3 mb-0">Already registered? <Link to="/login">Login</Link></p>
  </div>;
}
