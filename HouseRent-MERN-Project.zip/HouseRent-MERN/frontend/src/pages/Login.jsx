import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api.js";

export default function Login({ setUser }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();
    try {
      const { data } = await api.post("/auth/login", form);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      setUser(data.user);
      navigate(data.user.role === "admin" ? "/admin" : "/dashboard");
    } catch (err) {
      alert(err.response?.data?.message || "Login failed");
    }
  };

  return <div className="auth-card card shadow-sm p-4 mx-auto">
    <h2 className="mb-3">Login</h2>
    <form onSubmit={submit}>
      <input className="form-control mb-3" type="email" placeholder="Email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
      <input className="form-control mb-3" type="password" placeholder="Password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
      <button className="btn btn-primary w-100">Login</button>
    </form>
    <p className="mt-3 mb-0">New user? <Link to="/register">Create account</Link></p>
  </div>;
}
