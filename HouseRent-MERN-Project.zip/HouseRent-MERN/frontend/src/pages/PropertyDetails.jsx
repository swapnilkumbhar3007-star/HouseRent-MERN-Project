import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../services/api.js";

export default function PropertyDetails({ user }) {
  const { id } = useParams();
  const [p, setP] = useState(null);
  const [date, setDate] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    api.get(`/properties/${id}`).then(r => setP(r.data)).catch(e => alert(e.response?.data?.message || "Property not found"));
  }, [id]);

  if (!p) return <p>Loading...</p>;

  const book = async () => {
    if (!user) return alert("Please login to send a booking request.");
    if (!date) return alert("Select a move-in date.");
    try {
      await api.post("/bookings", { propertyId: id, moveInDate: date, message });
      alert("Booking request sent successfully.");
    } catch (e) {
      alert(e.response?.data?.message || "Booking failed");
    }
  };

  return <div className="row g-4">
    <div className="col-lg-7">
      {p.imageUrl ? <img src={p.imageUrl} className="img-fluid rounded-4 detail-img" alt={p.title}/> : <div className="detail-placeholder rounded-4">🏠</div>}
    </div>
    <div className="col-lg-5">
      <span className="badge text-bg-primary">{p.type}</span>
      <h1 className="mt-2">{p.title}</h1>
      <p>📍 {p.location}</p>
      <h3>₹{p.price.toLocaleString()} / month</h3>
      <p>{p.description}</p>
      <p><b>Bedrooms:</b> {p.bedrooms}</p>
      <hr/>
      <h5>Send booking request</h5>
      <input className="form-control mb-2" type="date" value={date} onChange={e=>setDate(e.target.value)}/>
      <textarea className="form-control mb-2" rows="3" placeholder="Message to owner" value={message} onChange={e=>setMessage(e.target.value)}/>
      <button className="btn btn-primary w-100" onClick={book}>Request Rental</button>
      <Link className="btn btn-link w-100 mt-2" to="/">Back to properties</Link>
    </div>
  </div>;
}
