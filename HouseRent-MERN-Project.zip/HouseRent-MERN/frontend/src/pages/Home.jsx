import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api.js";

export default function Home() {
  const [properties, setProperties] = useState([]);
  const [filters, setFilters] = useState({ search: "", type: "", minPrice: "", maxPrice: "" });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
      const { data } = await api.get("/properties", { params });
      setProperties(data);
    } catch (err) {
      alert(err.response?.data?.message || "Could not load properties");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div>
      <section className="hero rounded-4 p-4 p-md-5 mb-4">
        <h1 className="display-5 fw-bold">Find your next home</h1>
        <p className="lead">Search verified rental properties in one simple platform.</p>
      </section>

      <div className="card shadow-sm p-3 mb-4">
        <div className="row g-2">
          <div className="col-md-4"><input className="form-control" placeholder="Search title/location" value={filters.search} onChange={e => setFilters({...filters, search:e.target.value})}/></div>
          <div className="col-md-2"><select className="form-select" value={filters.type} onChange={e => setFilters({...filters, type:e.target.value})}><option value="">All types</option><option>Apartment</option><option>House</option><option>Room</option><option>Villa</option></select></div>
          <div className="col-md-2"><input type="number" className="form-control" placeholder="Min ₹" value={filters.minPrice} onChange={e => setFilters({...filters, minPrice:e.target.value})}/></div>
          <div className="col-md-2"><input type="number" className="form-control" placeholder="Max ₹" value={filters.maxPrice} onChange={e => setFilters({...filters, maxPrice:e.target.value})}/></div>
          <div className="col-md-2"><button className="btn btn-primary w-100" onClick={load}>Search</button></div>
        </div>
      </div>

      {loading ? <p>Loading...</p> : (
        <div className="row g-4">
          {properties.map(p => (
            <div className="col-md-6 col-lg-4" key={p._id}>
              <div className="card h-100 shadow-sm property-card">
                {p.imageUrl ? <img src={p.imageUrl} className="card-img-top property-img" alt={p.title}/> : <div className="property-placeholder">🏠</div>}
                <div className="card-body">
                  <span className="badge text-bg-primary">{p.type}</span>
                  <h5 className="mt-2">{p.title}</h5>
                  <p className="text-muted mb-1">📍 {p.location}</p>
                  <p className="fw-bold fs-5">₹{p.price.toLocaleString()} / month</p>
                  <Link className="btn btn-outline-primary w-100" to={`/property/${p._id}`}>View Details</Link>
                </div>
              </div>
            </div>
          ))}
          {!properties.length && <div className="col-12"><div className="alert alert-info">No approved properties found. Add one from a user dashboard.</div></div>}
        </div>
      )}
    </div>
  );
}
