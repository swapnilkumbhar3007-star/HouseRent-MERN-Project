import { useState } from "react";
import { Link, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Admin from "./pages/Admin.jsx";
import PropertyDetails from "./pages/PropertyDetails.jsx";

export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("user")); }
    catch { return null; }
  });
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
    navigate("/login");
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div className="container">
          <Link className="navbar-brand fw-bold" to="/">🏠 HouseRent</Link>
          <div className="d-flex gap-2 align-items-center">
            <Link className="btn btn-outline-light btn-sm" to="/">Properties</Link>
            {user ? (
              <>
                <Link className="btn btn-light btn-sm" to="/dashboard">Dashboard</Link>
                {user.role === "admin" && <Link className="btn btn-warning btn-sm" to="/admin">Admin</Link>}
                <button className="btn btn-danger btn-sm" onClick={logout}>Logout</button>
              </>
            ) : (
              <>
                <Link className="btn btn-light btn-sm" to="/login">Login</Link>
                <Link className="btn btn-outline-light btn-sm" to="/register">Register</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <main className="container py-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register setUser={setUser} />} />
          <Route path="/property/:id" element={<PropertyDetails user={user} />} />
          <Route path="/dashboard" element={user ? <Dashboard user={user} /> : <Navigate to="/login" />} />
          <Route path="/admin" element={user?.role === "admin" ? <Admin /> : <Navigate to="/" />} />
        </Routes>
      </main>

      <footer className="text-center py-4 border-top mt-5 text-muted">
        HouseRent • MERN Internship Project
      </footer>
    </>
  );
}
