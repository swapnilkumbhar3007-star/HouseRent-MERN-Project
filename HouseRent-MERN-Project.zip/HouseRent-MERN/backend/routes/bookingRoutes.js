import { Router } from "express";
import {
  createBooking, getMyBookings, getOwnerBookings
} from "../controllers/bookingController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = Router();

router.post("/", protect, createBooking);
router.get("/mine", protect, getMyBookings);
router.get("/owner", protect, getOwnerBookings);

export default router;
