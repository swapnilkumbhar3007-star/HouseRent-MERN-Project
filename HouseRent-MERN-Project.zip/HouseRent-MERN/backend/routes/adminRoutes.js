import { Router } from "express";
import {
  getPendingProperties, approveProperty, rejectProperty, getAllBookings
} from "../controllers/adminController.js";
import { protect, adminOnly } from "../middleware/authMiddleware.js";

const router = Router();

router.use(protect, adminOnly);
router.get("/properties/pending", getPendingProperties);
router.put("/properties/:id/approve", approveProperty);
router.put("/properties/:id/reject", rejectProperty);
router.get("/bookings", getAllBookings);

export default router;
