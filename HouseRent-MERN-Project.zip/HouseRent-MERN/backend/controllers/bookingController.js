import Booking from "../models/Booking.js";
import Property from "../models/Property.js";

export const createBooking = async (req, res, next) => {
  try {
    const { propertyId, moveInDate, message } = req.body;
    const property = await Property.findOne({ _id: propertyId, status: "approved" });

    if (!property) return res.status(404).json({ message: "Approved property not found" });
    if (String(property.owner) === String(req.user.id)) {
      return res.status(400).json({ message: "You cannot book your own property" });
    }

    const booking = await Booking.create({
      property: propertyId,
      renter: req.user.id,
      moveInDate,
      message
    });

    res.status(201).json(booking);
  } catch (err) {
    next(err);
  }
};

export const getMyBookings = async (req, res, next) => {
  try {
    const bookings = await Booking.find({ renter: req.user.id })
      .populate("property", "title location price")
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    next(err);
  }
};

export const getOwnerBookings = async (req, res, next) => {
  try {
    const properties = await Property.find({ owner: req.user.id }).select("_id");
    const ids = properties.map(p => p._id);
    const bookings = await Booking.find({ property: { $in: ids } })
      .populate("property", "title location")
      .populate("renter", "name email")
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (err) {
    next(err);
  }
};
